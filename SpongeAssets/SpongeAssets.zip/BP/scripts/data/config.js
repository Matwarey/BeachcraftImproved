export default
{
    "debug": true,
    "customcommands": {
        "prefix": "~",
        "bal": true,
        "shelp": true
}